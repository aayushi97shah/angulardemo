import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

let headers = new HttpHeaders();
headers = headers.set('Content-Type', 'application/json; charset=utf-8');
@Injectable({
  providedIn: 'root'
})
export class ListdataService {
  prefix: string = 'http://45.79.111.106/'
  constructor(private httpclient: HttpClient) { }
  public getrecords(): Observable<any> {
    return this.httpclient.get<any>(`${this.prefix}interview.json`, {
      headers
    });
  }
}
