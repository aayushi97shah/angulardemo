import { Component, OnInit } from '@angular/core';
import { ListdataService } from 'src/app/services/listdata.service';
declare const moment: any;
import *  as  data from '../../data.json';
@Component({
  selector: 'app-listdata',
  templateUrl: './listdata.component.html',
  styleUrls: ['./listdata.component.css']
})
export class ListdataComponent implements OnInit {
  list: any = (data as any).default;
  startDate: any;
  endDate: any;
  sDate: any;
  eDate: any;
  filteredlist: any = [];
  constructor(
    // private listservice: ListdataService
  ) { }
 
 
  ngOnInit(): void {   
   this.processStatistics();
  }
  processStatistics() {  
   
  this.filteredlist = this.list;   
    let newArray = [];
    let listid: any = [];
    for (let k of this.filteredlist) {
      let cntOfSumChats = 0;
      let cntOfMissedChats = 0;
      if (!listid.includes(k.websiteId)) {
        listid.push(k.websiteId);
        let tempvar = this.filteredlist.filter((val: any) => val.websiteId === k.websiteId)        
        for (let i = 0; i < tempvar.length; i++) {
          cntOfSumChats += tempvar[i].chats;
          cntOfMissedChats += tempvar[i].missedChats;
        }
        newArray.push({
          websiteId: k.websiteId,
          chats: cntOfSumChats,
          missedChats: cntOfMissedChats
        });
      }
    }
    this.filteredlist = newArray;
  }


  processStatisticss(startdate:any,enddate:any){
   let startdates= moment(startdate).format('YYYY-MM-DD');
   let enddates=moment(enddate).format('YYYY-MM-DD');   
    this.filteredlist=this.list.filter((val:any)=>moment(val.date).format('yyyy-MM-DD') >= moment(startdates).format('yyyy-MM-DD') && moment(val.date).format('yyyy-MM-DD') <= moment(enddates).format('yyyy-MM-DD'));  
    let newArray = [];
    let listid: any = [];
    for (let k of this.filteredlist) {
      let cntOfSumChats = 0;
      let cntOfMissedChats = 0;
      if (!listid.includes(k.websiteId)) {
        listid.push(k.websiteId);
        let tempvar = this.filteredlist.filter((val: any) => val.websiteId === k.websiteId)        
        for (let i = 0; i < tempvar.length; i++) {
          cntOfSumChats += tempvar[i].chats;
          cntOfMissedChats += tempvar[i].missedChats;
        }
        newArray.push({
          websiteId: k.websiteId,
          chats: cntOfSumChats,
          missedChats: cntOfMissedChats
        });
      }
    }
    this.filteredlist = newArray;

  }
}
