import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filtercount'
})
export class FiltercountPipe implements PipeTransform {

  transform(items: any[]): any {
    if (items && items.length > 0) {
      let newArray = [];
      for (let k of items) {
        let cntOfSumChats = 0;
        let cntOfMissedChats = 0;
        let arrayval: any;
        arrayval = items.filter((val: any) => val.websiteId === k.websiteId);
        for (let i = 0; i < arrayval.length; i++) {
          cntOfSumChats += arrayval[i].chats;
          cntOfMissedChats += arrayval[i].missedChats;
        }
        newArray.push({
          websiteId: k.websiteId,
          chats: cntOfSumChats,
          missedChats: cntOfMissedChats
        })
      }
      return newArray;
    } else {
      return [];
    }
  }

}
